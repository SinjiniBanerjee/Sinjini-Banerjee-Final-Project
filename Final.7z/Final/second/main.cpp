#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>
#include <omp.h>

int main()
{
    cv::Mat img = cv::imread("C:\\Users\\PC\\CLionProjects\\second\\house.jpeg", cv::IMREAD_GRAYSCALE);
    if (img.empty()) {
        std::cerr << "Error loading image" << std::endl;
        return -1;
    }

    cv::namedWindow("Input", cv::WINDOW_NORMAL);
    cv::namedWindow("Output", cv::WINDOW_NORMAL);
    cv::resizeWindow("Input", img.cols, img.rows);
    cv::resizeWindow("Output", img.cols, img.rows);

    cv::Mat outputImg = img.clone();

    int dx = 1, dy = 1, sobelKernelSize = 3, scaleFactor = 1, deltaValue = 1;

    while (true) {
        cv::Mat grad_x, grad_y, abs_grad_x, abs_grad_y;

#pragma omp parallel sections
        {
#pragma omp section
            cv::Sobel(img, grad_x, CV_16S, dx, 0, sobelKernelSize, scaleFactor, deltaValue);
#pragma omp section
            cv::Sobel(img, grad_y, CV_16S, 0, dy, sobelKernelSize, scaleFactor, deltaValue);
        }

        cv::convertScaleAbs(grad_x, abs_grad_x);
        cv::convertScaleAbs(grad_y, abs_grad_y);

#pragma omp parallel for
        for (int i = 0; i < img.rows; ++i) {
            for (int j = 0; j < img.cols; ++j) {
                outputImg.at<uchar>(i, j) = cv::saturate_cast<uchar>(0.5 * abs_grad_x.at<uchar>(i, j) + 0.5 * abs_grad_y.at<uchar>(i, j));
            }
        }

        cv::imshow("Input", img);
        cv::imshow("Output", outputImg);

        if (cv::waitKey(1) == 'q') break;
    }

    return 0;
}
