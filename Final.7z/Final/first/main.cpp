#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp>
#include <iostream>

int main()
{
    cv::Mat img = cv::imread("C:\\Users\\PC\\CLionProjects\\first\\house.jpeg", cv::IMREAD_GRAYSCALE);
    if (img.empty()) {
        std::cerr << "Error loading image" << std::endl;
        return -1;
    }

    cv::namedWindow("Input", cv::WINDOW_NORMAL);
    cv::namedWindow("Output", cv::WINDOW_NORMAL);
    cv::Mat outputImg;

    int dx = 1;
    int dy = 1;
    int sobelKernelSize = 5;
    int scaleFactor = 1;
    int deltaValue = 1;

    cv::Sobel(img, outputImg, CV_8UC1, dx, dy, sobelKernelSize, scaleFactor, deltaValue);

    cv::imshow("Input", img);
    cv::imshow("Output", outputImg);

    cv::waitKey(0);

    return 0;
}
